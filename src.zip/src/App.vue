<script setup>
import index from './pages/index.vue';
</script>

<template>
  <index></index>
  
</template>

<style scoped>

</style>
