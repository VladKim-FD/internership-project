<script>
import likedProducts from '../components/likedProducts.vue';

export default {
    components: {
        likedProducts
    }
}
</script>

<template>
    <likedProducts></likedProducts>
</template>
