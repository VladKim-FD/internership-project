<template>
  <footer class="footer">
    <div class="container footer__content">
      <div class="footer__content-logo">
        <img src="../assets/icons/footer-logo.svg" alt="" />
      </div>
      <div class="footer__content-links">
        <ul class="first-list">
          <li>
            <a href="#!">Home</a>
          </li>
          <li><a href="#!">Product card</a></li>
        </ul>
        <ul class="second-list">
          <li>
            <a href="#!">Payment and delivery</a>
          </li>
          <li>
            <a href="#!">Like</a>
          </li>
        </ul>
        <ul class="third-list">
          <li>
            <p>Contacts</p>
          </li>
          <li>
            <img src="../assets/icons/location-icon.svg" alt="" />
            <p>70 West Buckingham Ave. Farmingdale, NY 11735</p>
          </li>
          <li>
            <img src="../assets/icons/phone-icon.svg" alt="" />
            <p>+88 01911 717 490</p>
          </li>
          <li>
            <img src="../assets/icons/letter-icon.svg" alt="" />
            <p>contact@sportdriven.com</p>
          </li>
        </ul>
      </div>
    </div>
  </footer>
</template>

<script>
</script>

<style lang="scss">
@import "../assets/scss/components/footer.scss";
</style>