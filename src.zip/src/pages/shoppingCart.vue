<script>
import shoppingCart from '../components/shoppingCart.vue';
export default {
    components: {
        shoppingCart
    }
}
</script>

<template>
    <div>
        <shoppingCart></shoppingCart>
    </div>
</template>

