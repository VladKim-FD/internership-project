<script>
import productCheckout from '../components/productCheckout.vue';
export default {
    components: {
        productCheckout
    }
}
</script>

<template>
    <productCheckout></productCheckout>
</template>