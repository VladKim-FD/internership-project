<template>
    <productCard></productCard>
</template>

<script>
import productCard from '../components/productCard.vue';
export default {
    components: {
        productCard
    }
}
</script>