<template>
  
    <headerVue></headerVue>
    <mainVue></mainVue>
</template>

<script>
import headerVue from "../components/header.vue";
import mainVue from "../components/main.vue";
export default {
  components: {
    headerVue,
    mainVue
  },
};
</script>

